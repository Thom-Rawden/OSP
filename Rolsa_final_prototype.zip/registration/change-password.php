<?php

include "../templates/header.php";
require '../database/db.php';


$error = '';

if (isset($_GET['token'])) {
    $token = $_GET['token'];

    // Verify token exists
    $stmt = $pdo->prepare("SELECT * FROM users WHERE reset_token = ?");
    $stmt->execute([$token]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $newPassword = $_POST['password'];
            $confirmPassword = $_POST['confirm_password'];

            // Password Validation

            $pattern = '/^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[#?!@$%^&*-]).{8,}$/';
                if (!preg_match($pattern, $newPassword)) {
            $error = "<p>Password must be at least 8 characters long, include uppercase, lowercase, a number, and a special character. Please try again.</p>";
            } else {

                if ($newPassword !== $confirmPassword) {
                    $error = "<p>Passwords do not match, please try again.</p>";
                    
                } else {
                    $hash = password_hash($newPassword, PASSWORD_DEFAULT);

                    $stmt = $pdo->prepare("UPDATE users SET password_hash = ?, reset_token = NULL WHERE reset_token = ?");
                    $stmt->execute([$hash, $token]);

                    header("Location: ../registration/logout.php");
                    exit;
                }
            }
        }
    }
}




?>
<main>
    <div class = "auth-wrapper">
        <div class = "auth-card">

            <form method="post">

                <h1>Reset password</h1>

                <input type="password" name="password" placeholder="New Password" required><br>

                <input type="password" name="confirm_password" placeholder="Confirm Password" required><br>

                <button type="submit">Change Password</button>

                <div class="auth-error"><?php echo $error ?></div>

            
            </form>

        </div>
    </div>
</main>


<?php
include "../templates/footer.php";
?>