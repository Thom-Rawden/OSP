<?php

include "../templates/header.php";
require '../database/db.php';

$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $name = $_POST['name'];
    $plainPassword = $_POST['password'];

    // Name Validation

    if (!preg_match("/^[a-zA-Z' -]+$/", $name)) {
        $error = "<p>Name can only contain letters, spaces, hyphens, and apostrophes.</p>";
    } else {


        // Password Validation

        $pattern = '/^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[#?!@$%^&*-]).{8,}$/';

        // Check if password matches with confirmation
        if ($_POST['password'] !== $_POST['confirm_password']) {
            $error = "<p>Passwords do not match, please try again.</p>";
        } else

        // check password strength
        if (!preg_match($pattern, $plainPassword)) {
            $error = "<p>Password must be at least 8 characters long, include uppercase, lowercase, a number, and a special character. Please try again.</p>";
        } else {
        
        // Email Validation

        $pattern = '/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/';

        if (!preg_match($pattern, $email)) {
            $error = "<p>Invalid email format, please try again.</p>";
        } else {

            // Hash the password
            $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

            // All validations passed, proceed to store user
            $stmt = $pdo->prepare("INSERT INTO users (email, password_hash, name) VALUES (?, ?, ?)");
            try {
                $stmt->execute([$email, $password, $name]);
                header("Location: ../public/index.php");
            } catch (PDOException $e) {
                $error = "<p>Email already in use, please try again.</p>";
            }
            }
        }
    }
}


?>
<main>
    <div class = "auth-wrapper">
        <div class = "auth-card">

            <form method="POST">

                <h1>Sign Up</h1>

                <input type="text" name="name" placeholder="Name" required><br>

                <input type="email" name="email" placeholder="Email" required><br>

                <input type="password" name="password" placeholder="Password" required><br>

                <input type="password" name="confirm_password" placeholder="Confirm Password" required><br>

                <button type="submit">Sign-Up</button>

                <div class="auth-error"><?php echo $error ?></div>
        </div>
    </div>
</main>

<?php
include "../templates/footer.php";
?>