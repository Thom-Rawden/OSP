<?php
include "../templates/header.php";
require '../database/db.php';


if (!isset($_SESSION['user_id'])) {
    header("Location: ../registration/login.php");
    exit;
}


$error = '';

$stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user) {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $newName = $_POST['name'];

        // Name Validation

        if (!preg_match("/^[a-zA-Z' -]+$/", $newName)) {
            $error = "<p>Name can only contain letters, spaces, hyphens, and apostrophes.</p>";
        } else {

            $stmt = $pdo->prepare("UPDATE users SET name = ?");
            $stmt->execute([$newName]);

            $stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            // Set session name to new name
            $_SESSION['name'] = $user['name'];

            header("Location: ../public/account.php");
            exit;
        
        }
    }
}

?>

<main>
    <div class = "auth-wrapper">
        <div class = "auth-card">

            <form method="post">

                <h1>Change Name</h1>

                <input type="text" name="name" placeholder="New Name" required><br>

                <button type="submit">Change Name</button>

                <div class="auth-error"><?php echo $error ?></div>

            
            </form>

        </div>
    </div>
</main>

<?php
include "../templates/footer.php";
?>