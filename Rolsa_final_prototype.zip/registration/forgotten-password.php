<?php

include "../templates/header.php";
require '../database/db.php';

$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        // Create token
        $token = bin2hex(random_bytes(16));

        $stmt = $pdo->prepare("UPDATE users SET reset_token = ? WHERE email = ?");
        $stmt->execute([$token, $email]);
        // Redirect to reset page with new token
        header("Location: ../registration/change-password.php?token=$token");
        exit;
    } else {
        $error = "<p>Email Not Found</p>";
    }
}

?>
<main>
    <div class = "auth-wrapper">
        <div class = "auth-card">

            <form method="post">

                <h1>Forgotten Password</h1>

                <input type="email" name="email" placeholder="Email" required><br>

                <button type="submit">Reset Password</button>

                <div class="auth-error"><?php echo $error ?></div>

            </form>

        </div>
    </div>
</main>

<?php
include "../templates/footer.php";
?>