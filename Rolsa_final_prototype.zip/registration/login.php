<?php

include "../templates/header.php";
require '../database/db.php';

$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Fetch user by email
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    // Verify password
    if ($user && password_verify($password, $user['password_hash'])) {
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['name'] = $user['name'];
        $_SESSION['email'] = $user['email'];
        header("Location: ../public/index.php");
        exit;
    } else {
        // Link to reset password page if password is incorrect
        $error = "<p>Invalid email or password. <br><a href = '../registration/forgotten-password.php'>Click here</a> to reset password.</p>";
    }
}



?>
<main>
    <div class = "auth-wrapper">
        <div class = "auth-card">

            <form method="post">

                <h1>Login</h1>

                <input type="email" name="email" placeholder="Email" required><br>

                <input type="password" name="password" placeholder="Password" required><br>

                <button type="submit">Login</button>

                <div class="auth-error"><?php echo $error ?></div>

            
            </form>

            <div class="auth-links">
                <a href="../registration/signup.php">Create an account</a>
            </div>

        </div>
    </div>
</main>


<?php
include "../templates/footer.php";
?>