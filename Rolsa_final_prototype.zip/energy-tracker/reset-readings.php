<?php
session_start();
require "../database/db.php";

//redirect to login if user is not logged in
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../public/account.php');
    exit;
}

$user_id = $_SESSION['user_id'] ?? null;
if (empty($user_id)) {
    header('Location: ../public/account.php');
    exit;
}

$token = $_POST['csrf_token'] ?? '';

if (empty($token) || empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
    header('Location: ../public/energy-tracking.php');
    exit;
}

try {
    // find readings belonging to user
    $stmt = $pdo->prepare('SELECT reading_id FROM energy_usage WHERE user_id = ?');
    $stmt->execute([(int)$user_id]);
    $found = $stmt->fetchColumn();

    if ($found === FALSE) {
        header('Location: ../public/energy-tracking.php');
        exit;
    }

    // delete readings
    $del = $pdo->prepare('DELETE FROM energy_usage WHERE user_id = ?');
    $del->execute([(int)$user_id]);
    
    header('Location: ../public/energy-tracking.php');
    exit;

} catch (Exception $e) {
    error_log('reset-readings error: ' . $e->getMessage());
    header('Location: ../public/energy-tracking.php');
    exit;
}