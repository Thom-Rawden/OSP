<?php
session_start();
require '../database/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../public/account.php');
    exit;
}

$user_id = $_SESSION['user_id'] ?? null;
if (empty($user_id)) {
    header('Location: ../public/account.php');
    exit;
}

$consultation_id = isset($_POST['consultation_id']) ? (int)$_POST['consultation_id'] : 0;
$token = $_POST['csrf_token'] ?? '';

if ($consultation_id <= 0 || empty($token) || empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
    header('Location: ../public/account.php');
    exit;
}

try {
    // ensure booking belongs to user
    $stmt = $pdo->prepare('SELECT consultation_id FROM consultations WHERE consultation_id = ? AND user_id = ? LIMIT 1');
    $stmt->execute([$consultation_id, (int)$user_id]);
    $found = $stmt->fetchColumn();

    if ($found === FALSE) {
        header('Location: ../public/account.php');
        exit;
    }

    // delete booking
    $del = $pdo->prepare('DELETE FROM consultations WHERE consultation_id = ? AND user_id = ?');
    $del->execute([$consultation_id, (int)$user_id]);

    $_SESSION['cancel_success'] = 'Booking cancelled.';
    header('Location: ../public/account.php');
    exit;
} catch (Exception $e) {
    error_log('cancel-booking error: ' . $e->getMessage());
    header('Location: ../public/account.php');
    exit;
}
?>