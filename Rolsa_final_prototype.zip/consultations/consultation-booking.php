<?php
include "../templates/header.php";
require '../database/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../registration/login.php");
    exit;
}

$result = '';

// When form is submitted, create a database entry
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if(isset($_POST['create-booking'])) {

        $date = $_POST['date'];
        $subject = $_POST['subject'];
        $details = $_POST['details'];
        $address = $_POST['address'];

        $date = $_POST['date'];

        // Date validation - dates cannot be in the past
        if (strtotime($date) < strtotime('today')) {
            $result = "You cannot book a past date.";
        } else {

            $sql = "INSERT INTO consultations (user_id, date, subject, details, address) VALUES (?, ?, ?, ?, ?)";
            $stmt = $pdo->prepare($sql);

            try {
                $stmt->execute([$_SESSION['user_id'], $date, $subject, $details, $address]);
                $result = "Booking created successfully!";
            } catch (PDOException $e) {
                if ($e->getCode() == 23000) {
                    $result = "A booking already exists on that date.";
                } else {
                    $result = "Error: " . $e->getMessage();
                }
            }

        }
    }
}

$stmt = $pdo->query("SELECT date FROM consultations");
$dates = $stmt->fetchAll(PDO::FETCH_COLUMN);

?>

<script>
    // Script to calculate the estimated quote
function calculateEstimate() {
    const product = document.getElementById("product").value;
    const amountInput = document.getElementById("amount");
    const estimateBox = document.getElementById("estimate");

    // Validate amount
    const amount = parseInt(amountInput.value);
    if (isNaN(amount) || amount < 1) {
        estimateBox.innerText = "Please enter a valid amount.";
        return;
    }

    // Price dictionary
    const priceDict = {
        "solar-panel": 400.00,
        "charging-station": 600.00
    };

    // Validate product
    if (!priceDict[product]) {
        estimateBox.innerText = "Please select a valid product.";
        return;
    }

    const total = priceDict[product] * amount;
    estimateBox.innerText = "£" + total.toFixed(2);
}
</script>

<main>

<div class="consultation-grid">
    <!-- Booking section -->
    <div class="consultation-left">

        <form method="POST">
            <label>Date:</label>
            <input type="text" id="bookingDate" name="date"  style="display:none;" required>

            <label>Subject:</label>
            <input type="text" name="subject" placeholder="e.g. solar panel installation" required>

            <label>Details:</label>
            <textarea name="details"  placeholder="Please enter any relevant information for consideration prior to a consultation" required></textarea>

            <!-- Address - autofills using postcodes.io API -->

            <label>House number and street:</label>
            <input type="text" id="streetInput" name="street" placeholder="e.g. 67 Downing street" required>
            
            <label>Postcode:</label>
            <input type="text" id="postcodeInput" placeholder="Optional: enter postcode to assist address entry">

            <label>Select Address:</label>
            <select id="addressSelect" style="display:none;"></select>

            <label>Address:</label>
            <textarea id="addressInput" name="address" required></textarea>

            <h2><?php echo $result ?></h2>
            <button type="submit" name="create-booking">Create Booking</button>
        </form>

        <!-- Js calendar - open source library -->
        <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
        <script>
            // create json format of booked dates
            const bookedDates = <?= json_encode($dates) ?>;
            
            flatpickr("#bookingDate", {
                // Calendar always appears
                inline: true,
                minDate: "today",
                disable: bookedDates,
                dateFormat: "Y-m-d",

                // Make past dates and unavailable dates appear differently
                onDayCreate: function(dObj, dStr, fp, dayElem) {
                    const date = fp.formatDate(dayElem.dateObj, "Y-m-d");
                    if (bookedDates.includes(date)) {
                        dayElem.classList.add("booked-date");
                    }
                }
            });

        </script>
        <script>
        // API autofill for address input
        document.getElementById("postcodeInput").addEventListener("blur", function () {
            const postcode = this.value.trim();

            if (!postcode) return;

            fetch(`https://api.postcodes.io/postcodes/${postcode}`)
                .then(res => res.json())
                .then(data => {
                    if (data.status !== 200) { 
                        return;
                    }

                    const result = data.result;

                    // Build a single-line address
                    const address = `${result.admin_ward}, ${result.admin_district}, ${result.region}`;

                    function updateFullAddress() {
                        const street = document.getElementById("streetInput").value.trim();
                        const auto = document.getElementById("addressInput").dataset.auto || "";
                        document.getElementById("addressInput").value = street ? `${street}, ${auto}` : auto;
                    }

                    document.getElementById("streetInput").addEventListener("input", updateFullAddress);


                    // Autofill the text area - concatenate with street name and number
                    const autoAddress = `${result.admin_ward}, ${result.admin_district}, ${result.region}`;
                    const addressInput = document.getElementById("addressInput");

                    addressInput.dataset.auto = autoAddress;
                    updateFullAddress();


                })
                .catch(err => console.error(err));
        });
        </script>

    </div>

    <!-- Estimated quote section -->
    <div class="consultation-right">
        <form method="POST">
            <h1>Quote Estimate Calculator:</h1>

            <label>Product(s):</label>

            <select id="product" name="product" oninput="calculateEstimate()">
                <option value="solar-panel">Solar Panel</option>
                <option value="charging-station">Car Charging Station</option>
            </select>

            <label>Amount installed:</label>
            <input id="amount" type="number" name="subject" min="1" required oninput="calculateEstimate()">

            <!-- Output the quote estimate to user -->
             <h2>Estimate:</h2>
            <span id="estimate">No product selected.</span>
        </form>
    </div>
</main>

<?php
include "../templates/footer.php";
?>