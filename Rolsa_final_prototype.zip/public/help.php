<?php
// Include header template
include "../templates/header.php";
?>

<main>

<div class="textpage-wrapper">
    <h1>Help</h1>

    <h2>Sources:</h2>
    <p>This site sources it's information from many places.</p>

    <h3>UK Government:</h3>
    <p>For the carbon footprint calculator, the average car travel distance per week 
was sourced from the UK Government website: <a href="https://www.gov.uk/government/statistics/national-travel-survey-2024/nts-2024-household-car-availability-and-trends-in-car-trips">click here</a> for more information.
    </p>

    <h3>Confused.com:</h3>
    <p>For the carbon footprint calculator, the average electricity usage per week 
was sourced from Confused.com: <a href="https://www.confused.com/gas-electricity/guides/average-energy-bills-in-the-uk">Click here</a> for more information.

    <h3>British gas:</h3>
    <p>For the carbon footprint calculator, the average gas consumption per month 
was sourced from British gas: <a href="https://www.britishgas.co.uk/energy/guides/average-bill.html?msockid=015445b2db2e6a8337785350dad26b19 ">Click here</a> for more information.

</div>

</main>

<?php
include "../templates/footer.php";
?>