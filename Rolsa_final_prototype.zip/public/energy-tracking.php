<?php
// include header and database
include "../templates/header.php";
require "../database/db.php";

//redirect to login if user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../registration/login.php");
    exit;
}

// Generate token for resetting readings
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
}


$user_id = (int)$_SESSION['user_id'];
$GLOBALS['pdo'] = $pdo;

// function to get the users energy meter readings
function get_user_readings(?int $user_id): array
{
    if (empty($user_id) || !isset($GLOBALS['pdo'])) {
        return [];
    }

    try {
        $pdo = $GLOBALS['pdo'];
        $stmt = $pdo->prepare(
            "SELECT reading_id, reading_date, kwh_used
             FROM energy_usage
             WHERE user_id = ?
             ORDER BY reading_date DESC"
        );
        $stmt->execute([(int)$user_id]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $rows ?: [];
    } catch (Exception $e) {
        return [];
    }
}

// insert reading into database
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    
    $current_reading = isset($_POST['meter_reading']) ? (float)$_POST['meter_reading'] : null;
    $date = $_POST['reading_date'] ?? null;

    if ($current_reading !== null && $date !== null) {
        $stmt = $pdo->prepare("
            SELECT meter_reading 
            FROM energy_usage 
            WHERE user_id = ? 
            ORDER BY reading_date DESC 
            LIMIT 1
        ");
        $stmt->execute([$user_id]);
        $previous = $stmt->fetchColumn();

        $kwh_used = $previous ? ($current_reading - $previous) : 0;
        if ($kwh_used < 0) $kwh_used = 0;

        $stmt = $pdo->prepare("
            INSERT INTO energy_usage (user_id, reading_date, meter_reading, kwh_used)
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([$user_id, $date, $current_reading, $kwh_used]);
    }
}

$readings = get_user_readings($user_id);
?>

<main>
    <div class="energy-wrapper">
        
        <div class="energy-form">

            <form method="post">
                <label>Meter Reading (kWh):</label>
                <input type="number" step="0.01" name="meter_reading" required>

                <label>Date:</label>
                <input type="text" id="readingDate" name="reading_date" style="display:none;" required>
                <div id="readingCalendar"></div>

                <button type="submit">Save Reading</button>
            </form>
        </div>

    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script>
        flatpickr("#readingCalendar", {
            inline: true,
            maxDate: "today",
            dateFormat: "Y-m-d",
            onChange: function(selectedDates, dateStr) {
                document.getElementById("readingDate").value = dateStr;
            }
        });
    </script>

    <div class="energy-chart-box">
        <div class="chart-container">
            <canvas id="energyChart"></canvas>
        </div>

        <!-- Button to reset all energy reading entries -->
        <form method="POST" action="../energy-tracker/reset-readings.php" style="display:inline;">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
            <button type="submit" class="btn" onclick="return confirm('Reset energy reading entries?');">Reset</button>
        </form>

    </div>
</div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <!-- Format and chart readings -->
    <script>
    document.addEventListener('DOMContentLoaded', function () {
        const energyData = <?php echo json_encode($readings); ?>;

        function generateDateRange(start, end) {
            const dates = [];
            let current = new Date(start);
            while (current <= new Date(end)) {
                dates.push(current.toISOString().split("T")[0]);
                current.setDate(current.getDate() + 1);
            }
            return dates;
        }

        const dates = energyData.map(item => item.reading_date);
        const minDate = dates[dates.length - 1];
        const maxDate = dates[0];

        const fullDateRange = generateDateRange(minDate, maxDate);

        const usageMap = {};
        energyData.forEach(item => {
            usageMap[item.reading_date] = parseFloat(item.kwh_used);
        });

        const values = fullDateRange.map(date => usageMap[date] || 0);

        const ctx = document.getElementById('energyChart').getContext('2d');

        new Chart(ctx, {
            type: 'line',
            data: {
                labels: fullDateRange,
                datasets: [{
                    label: 'Energy usage (kWh)',
                    data: values,
                    borderColor: 'rgba(33, 110, 243, 1)',
                    backgroundColor: 'rgba(173, 216, 230, 0.4)',
                    tension: 0.3
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });
    });
    </script>

</main>

<?php
include "../templates/footer.php";
?>
