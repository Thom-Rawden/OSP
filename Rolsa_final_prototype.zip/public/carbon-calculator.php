<?php
// Include the header template and config
include "../templates/header.php";
?>


<script>
    function calculateFootprint() {
        const carKm = parseFloat(document.getElementById("car_km").value) || 0;
        const electricity = parseFloat(document.getElementById("electricity").value) || 0;
        const gas = parseFloat(document.getElementById("gas").value) || 0;

        // Kg of CO2 per km
        const carFactor = 0.21;
        // Kg of CO2 per kWh
        const elecFactor = 0.233;
        // Kg CO2 per kWh
        const gasFactor = 0.184;

        const total =
            (carKm * carFactor) +
            (electricity * elecFactor) +
            (gas * gasFactor);

        document.getElementById("result").innerText =
            total.toFixed(2) + " kg CO2";

        // average consumption for advice on what to cut down on
        const carAvg = 150;
        const elecAvg = 225;
        const gasAvg = 1200;

        // collect applicable advice messages
        let advice = [];

        if (carKm > carAvg) {
            advice.push("You’re currently driving quite a long distance each week, which increases your carbon footprint more than you might expect. If it’s possible for your lifestyle, even small reductions—like combining trips, car‑sharing, or using public transport occasionally—could make a meaningful difference.");
        }

        if (electricity > elecAvg) {
            advice.push("You’re using a fairly high amount of electricity this month compared with typical household patterns. If it fits your routine, even small adjustments—like switching off unused appliances, improving insulation, or choosing energy‑efficient bulbs—could help bring that number down over time.");
        }

        if (gas > gasAvg) {
            advice.push("Your monthly gas usage is on the higher side, which can increase both your carbon footprint and your energy costs. If it works for your home, steps like lowering the thermostat slightly, improving heating efficiency, or reducing hot‑water use can make a noticeable difference.");
        }

        // show either the collected advice or the default message
        if (advice.length === 0) {
            document.getElementById("advice").innerText = "Your current emissions are at a good rate!";
        } else {
            document.getElementById("advice").innerText = advice.join("\n\n");
        }

        
    }

</script>

<main>
    <div class="carbon-wrapper">
        <h2>Carbon Footprint Calculator:</h2>
    <!-- Form for carbon footprint calculator -->
        <form method="POST" class="carbon-form">

            <label>Car travel (km per week):</label><br>
            <input type="number" id="car_km" name="car_km" oninput="calculateFootprint()"><br><br>

            <label>Electricity use (kWh per month):</label><br>
            <input type="number" id="electricity" name="electricity" oninput="calculateFootprint()"><br><br>

            <label>Gas use (kWh per month):</label><br>
            <input type="number" id="gas" name="gas" oninput="calculateFootprint()"><br><br>

            <div class="carbon-result-box">
                <p>Total:</p>
                <span id="result">0 kg CO2</span>

                <p style="margin-top:1rem;">Advice:</p>
                <span id="advice">Your current emissions are at a good rate!</span>
            </div>
        </form>
        <p style="margin-top:1rem;">
            Advice generated using estimates of average consumption per person. for more information on sources visit the <a href="../public/help.php">help</a> page.
        </p>
    </div> 
</main>

<?php
// Include the footer template
include "../templates/footer.php";
?>

