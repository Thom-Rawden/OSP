<?php
// Include header template and config
include "../templates/header.php";
?>


<div class="home-intro">
    <h1>Welcome to Rolsa Technologies</h1>
    
    <!-- First div, containing chart and some text -->
    <div class="">

        <p>To commit to a sustainable future, in 2026 so far, we have installed x solar panels, saving y tons of carbon emissions. 
Our services include solar panels, electric car charging stations and so much more. Book a consultation to find out how you can have your own installation!</p>
        <!-- Chart.js solar panel installation chart -->
        <div class="chart-container">
            <canvas id="salesChart"></canvas>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

        <script>
        document.addEventListener('DOMContentLoaded', function () {
            // Test data for chart - could be replaced with real data from database
            const testData = [
                {date: '2022', amount: 1200},
                {date: '2023', amount: 1500},
                {date: '2024', amount: 3000},
                {date: '2025', amount: 7000}
            ];

            const labels = testData.map(item => item.date);
            const values = testData.map(item => item.amount);

            const ctx = document.getElementById('salesChart').getContext('2d');

            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Solar panels installed',
                        data: values,
                        borderColor: 'rgba(33, 110, 243, 1)',
                        backgroundColor: 'rgba(173, 216, 230, 0.4)',
                        tension: 0.3
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: { beginAtZero: true }
                    }
                }
            });
        });
        </script>
        <p>Data used for display purposes, currently innacurate and fictional.</p>
    </div>
    
    <h2>Emerging Green Technologies:</h2>
    <div class="home-two-column">
        
        <div>
            <!-- Free use image -->
            <img src="https://tse3.mm.bing.net/th/id/OIP.gGmXSOxz079BiOzW_xy6uQHaE8?rs=1&pid=ImgDetMain&o=7&rm=3"  alt="Some solar panels">
        </div>

        <div class="home-text-block">
            <h3>Solar panels:</h3>
            <p>Solar panels offer a powerful environmental benefit by generating electricity without producing direct carbon emissions, helping cut greenhouse gases that drive climate change
 (source: <a href = "https://www.newpoweruk.co.uk">newpower.co.uk</a>)</p>
        </div>
    </div>

    <div class="home-two-column">
        
        <div class="home-text-block">
            <h3>Floating wind farms:</h3>
            <p>A floating wind farm consists of wind turbines mounted on floating structures, allowing them to generate electricity in deeper waters where traditional fixed-foundation turbinges are not feasible
 (source: <a href = "https://en.wikipedia.org/wiki/Floating_wind_turbine">Wikipedia</a>)               
            </p>
        </div>


        <div>
            <img src="https://tse3.mm.bing.net/th/id/OIP.LrAY1bFCdsW-ZmyE5TgKgQHaE7?rs=1&pid=ImgDetMain&o=7&rm=3" alt="A floating wind farm">
        </div>

    </div>
</main>

<?php
// use footer template

include "../templates/footer.php"
?>