<?php
// Include header template
include "../templates/header.php";
?>

<main>

<div class="textpage-wrapper">
    <h1>Contact:</h1>
    <p>Rolsa is committed to building a cleaner, smarter future through accessible green technology. We believe innovation should empower people, not overwhelm them — and we’re proud to help communities take meaningful steps toward sustainability. Stay connected with us and follow our journey.</P>

    <a class="social-link" href="https://www.instagram.com/"><img class="social-icon" src="../public/images/instagram-logo.png" alt="Instagram logo">Our Instagram!</a>
    <br>
    <a class="social-link" href="https://www.x.com/"><img class="social-icon" src="../public/images/twitter-logo.png" alt="Instagram logo">Our X page!</a>
    <br>
    <h2>Email Address:</h2>
    <p>example@example.com</p>
    <p>Do not contact this email address, it is an example made for prototype purposes.</p>

    <h2>Email Address:</h2>
    <p>3525-54326</p>
    <p>Do not contact this phone number, it is an example made for prototype purposes.</p>

</div>

</main>

<?php
include "../templates/footer.php";
?>