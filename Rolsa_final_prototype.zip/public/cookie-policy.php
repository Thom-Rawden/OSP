<?php
// Include header template
include "../templates/header.php";
?>

<main>

<div class="textpage-wrapper">
    <h1>Cookie Policy</h1>
    <p>This Cookie Policy explains how this website uses cookies to provide 
essential functionality and improve your experience. By continuing to use 
this site, you agree to the use of the cookies described below.</P>

    <h2>What Are Cookies?</h2>
    <p>Cookies are small text files stored on your device when you visit a 
website. They help the site remember your actions and preferences so that 
it functions correctly and provides a smoother experience.</p>

    <h2>Cookies We Use:</p>
    
    <h3>Accessibility Preference Cookies</h3>
    <p>Names: bold_text, low_contrast, dyslexia_font</p>
    <p>These cookies store your chosen accessibility settings such as text 
size, contrast and font. No personal data is stored by these cookies.
    </p>

    <h3>Session Cookies</h3>
    <p>These cookies maintain your login session so you can access your 
account, manage bookings, and use parts of the website. No personal data is 
stored by the cookie itself, only a session ID used to keep you logged in.</p>

    <h2>Managing Cookies</h2>
    <p>You can control or delete cookies through your browser settings. However, 
disabling session cookies will prevent you from logging in or using 
account-related features.</p>

</div>

</main>

<?php
include "../templates/footer.php";
?>