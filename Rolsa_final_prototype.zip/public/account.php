<?php
// Include header template and database
include "../templates/header.php";
require '../database/db.php';

// Verfiy user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../registration/login.php");
    exit;
}

// Generate token for consultation cancelling
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
}

// Function to get user bookings
function get_user_bookings(?int $user_id): array
{
    if (empty($user_id) || !isset($GLOBALS['pdo'])) {
        return [];
        
    }

    try {
        $pdo = $GLOBALS['pdo'];
        $stmt = $pdo->prepare(
            "SELECT consultation_id, user_id, date, subject, details, status, address
            FROM consultations
            WHERE user_id = ?
            ORDER BY date DESC"
        );

        $stmt->execute([(int)$user_id]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $rows ?: [];
    } catch (Exception $e) {
        error_log('get_user_bookings error: ' . $e->getMessage());
        return [];
    }
}




?>

<main class="account-page">

<div class="account-panel">
    <h1>My Account:</h1>
    <a href="../registration/change-name.php" class="btn">Change Name</a>
    <a href="../registration/reset-password.php" class="btn">Change Password</a>
</div>

<div class="consultations-panel">
    <h1>My Consultations:</h1>

    <?php
        // Set user_id to current session user
        $user_id = (int)($_SESSION['user_id'] ?? 0);
        // get bookings based on user
        $bookings = get_user_bookings($user_id);


        if (empty($bookings)) { ?>
            <div class="consultation-item">
                <h2>No bookings found.</h2>
            </div>
        <?php
        } else {
            foreach ($bookings as $b) { ?>
                <div class="">
                    <h2><?php echo htmlspecialchars(ucfirst($b['subject']) . ' consultation, '. ucfirst($b['date'])); ?></h2>
                </div>

                <form method="POST" action="../consultations/cancel-booking.php" style="display:inline;">
                    <input type="hidden" name="consultation_id" value="<?php echo (int)$b['consultation_id']; ?>">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                    <button type="submit" class="btn" onclick="return confirm('Cancel this booking?');">Cancel</button>
                </form>

            <?php
                }
            }
        ?>
    </div>

</main>

<?php
include "../templates/footer.php";
?>