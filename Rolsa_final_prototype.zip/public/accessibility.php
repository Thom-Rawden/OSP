<?php
// Include header template
include "../templates/header.php";
?>

<main>
    <div class="accessibility-wrapper">


<h1>Accessibility Settings</h1>

    <h3>Accessibility</h3>

    <!-- Accessibility options -->
    <div class="accessibility-buttons">
        <button id="toggleBackground">Toggle Low Contrast</button>
        <button id="toggleBold">Toggle Bold Text</button>
        <button id="toggleFont">Toggle Dyslexia Font</button>
    </div>

    <div class="accessibility-info">
        <p>
            This site uses cookies to track your accessibility preferences. See how cookies are used <a href="../public/cookie-policy.php">here.</a>
        </p>
    </div>

        <script>
            document.getElementById("toggleBold").addEventListener("click", function () {
                const isBold = document.body.classList.contains("bold-text");

                // Toggle bold text
                if (isBold) {
                    document.cookie = "bold_text=0; path=/; max-age=10";   
                } else {
                    document.cookie = "bold_text=1; path=/; max-age=31536000";
                }

                location.reload();
            })

            document.getElementById("toggleBackground").addEventListener("click", function () {
                const isContrast = document.body.classList.contains("low-contrast");

                // Toggle high contrast background
                if (isContrast) {
                    document.cookie = "low_contrast=0; path=/; max-age=10";   
                } else {
                    document.cookie = "low_contrast=1; path=/; max-age=31536000";
                }

                location.reload();
            })

            document.getElementById("toggleFont").addEventListener("click", function () {
                const isContrast = document.body.classList.contains("dyslexia-font");

                // Toggle dyslexia friendly font
                if (isContrast) {
                    document.cookie = "dyslexia_font=0; path=/; max-age=10";   
                } else {
                    document.cookie = "dyslexia_font=1; path=/; max-age=31536000";
                }

                location.reload();
            })
        </script>
    </div>
</main>

<?php
// use footer template
include "../templates/footer.php"
?>