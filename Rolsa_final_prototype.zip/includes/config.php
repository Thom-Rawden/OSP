<?php

$bold = isset($_COOKIE['bold_text']) && $_COOKIE['bold_text'] === '1';

$contrast = isset($_COOKIE['low_contrast']) && $_COOKIE['low_contrast'] === '1';

$dyslexia_font = isset($_COOKIE['dyslexia_font']) && $_COOKIE['dyslexia_font'] === '1';