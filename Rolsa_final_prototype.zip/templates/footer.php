<footer class="footer">
    <a href="../public/cookie-policy.php" class="btn">Cookie Policy</a>
    <a href="../public/help.php" class="btn">Help</a>
    <a href="../public/contact.php" class="btn">Contact Information</a>
    <a href="../public/accessibility.php" class="btn">Accessibility</a>
</footer>
</body>
</html>