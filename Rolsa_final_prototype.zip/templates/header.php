<?php
// Include config file
require "../includes/config.php";

session_start();

$page_title = "Rolsa Technologies";
?>

<!-- Header template for pages -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>

    <!-- Styling for js calendar -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <link rel="stylesheet" href="../public/css/styles.css">

</head>
<body class="<?php echo $bold ? 'bold-text' : ''; ?> <?php echo $contrast ? 'low-contrast' : ''; ?> <?php echo $dyslexia_font ? 'dyslexia-font' : ''; ?>">

<header class="header">

    <!-- home page and contact -->
    <nav class="left-header" aria-label="Primary">
        <a href="../public/index.php" class="btn">Home</a>
        <a href="../public/account.php" class="btn">Account</a>
    </nav>

    <!-- site functions and accessibility -->
    <nav class="centre-header" aria-label="Site functions">
        <a href="../public/carbon-calculator.php" class="btn">Carbon footprint calculator</a>
        <a href="../consultations/consultation-booking.php" class="btn">Book a consultation</a>
        <a href="../public/energy-tracking.php" class="btn">Energy tracking tool</a>
        
    </nav>

    <!-- Registration and login  -->
    <nav class="right-header" aria-label="User">
        <?php if (isset($_SESSION['user_id'])) {?>
            <a href="../registration/logout.php" class="btn btn-primary">Logout</a>
            <span>Welcome, <?php echo htmlspecialchars($_SESSION['name']); ?>!</span>
        <?php } else { ?>
            <a href="../registration/login.php" class="btn btn-primary">Login</a>
            <a href="../registration/signup.php" class="btn btn-secondary">Sign up</a>
        <?php } ?>
        
    </nav>

</header>